package com.example.myinvestmentplanner

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import java.text.NumberFormat
import java.util.Locale
import kotlin.math.pow

private const val DAYS_PER_YEAR = 365.0

data class Snapshot(
    val period: Int,
    val day: Int,
    val balance: Double,
    val periodProfit: Double,
    val totalProfit: Double
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            MaterialTheme {
                Surface(modifier = Modifier.fillMaxSize()) {
                    InvestmentPlannerScreen()
                }
            }
        }
    }
}

@Composable
fun InvestmentPlannerScreen() {
    var principalText by remember { mutableStateOf("1000") }
    var dailyRateText by remember { mutableStateOf("0.274") }
    var daysText by remember { mutableStateOf("365") }
    var taxText by remember { mutableStateOf("30") }
    var reportType by remember { mutableStateOf("Daily") }

    val principal = principalText.toDoubleOrNull()?.coerceAtLeast(0.0) ?: 0.0
    val dailyRate = (dailyRateText.toDoubleOrNull() ?: 0.0).coerceAtLeast(0.0) / 100.0
    val days = (daysText.toIntOrNull() ?: 0).coerceIn(0, 36500)
    val taxRate = ((taxText.toDoubleOrNull() ?: 0.0).coerceIn(0.0, 100.0)) / 100.0

    val grossFinal = principal * (1.0 + dailyRate).pow(days)
    val grossProfit = grossFinal - principal
    val taxAmount = grossProfit.coerceAtLeast(0.0) * taxRate
    val netFinal = grossFinal - taxAmount
    val apr = dailyRate * DAYS_PER_YEAR * 100.0
    val apy = ((1.0 + dailyRate).pow(365) - 1.0) * 100.0

    val reportRows = remember(principal, dailyRate, days, reportType) {
        buildReport(principal, dailyRate, days, reportType)
    }

    Column(
        modifier = Modifier.fillMaxSize().verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("My Investment Planner", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("Daily compounding • 365 calendar days/year", style = MaterialTheme.typography.bodyMedium)

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Investment inputs", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                NumberInput("Investment amount (₹)", principalText) { principalText = it }
                NumberInput("Daily interest rate (%)", dailyRateText) { dailyRateText = it }
                NumberInput("Duration (calendar days)", daysText) { daysText = it }
                NumberInput("Tax on profit (%)", taxText) { taxText = it }
                Text("Compounding is applied once per calendar day, including weekends and holidays.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Estimated result", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("Final amount after estimated tax", style = MaterialTheme.typography.bodyMedium)
                Text(money(netFinal), style = MaterialTheme.typography.headlineMedium, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold)
                ResultLine("Initial investment", money(principal))
                ResultLine("Gross final amount", money(grossFinal))
                ResultLine("Gross profit", money(grossProfit))
                ResultLine("Estimated tax", money(taxAmount))
                HorizontalDivider()
                ResultLine("Net profit after tax", money(netFinal - principal), true)
                HorizontalDivider()
                ResultLine("APR (nominal)", percent(apr))
                ResultLine("APY (effective)", percent(apy))
                Text("APR = daily rate × 365. APY includes daily compounding over 365 days.",
                    style = MaterialTheme.typography.bodySmall)
            }
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("Growth report", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Daily", "Weekly", "Monthly", "Yearly").forEach { type ->
                        FilterChip(
                            selected = reportType == type,
                            onClick = { reportType = type },
                            label = { Text(type) }
                        )
                    }
                }
                Text("Period • Day • Closing balance • Profit in period", style = MaterialTheme.typography.bodySmall)
                reportRows.forEach { row ->
                    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                        ResultLine("${reportType} ${row.period} (day ${row.day})", money(row.balance), true)
                        Text("Period profit: ${money(row.periodProfit)}  |  Total profit: ${money(row.totalProfit)}",
                            style = MaterialTheme.typography.bodySmall)
                        HorizontalDivider()
                    }
                }
                if (reportRows.isEmpty()) Text("Enter a duration greater than zero to see the report.")
            }
        }

        Text(
            "Important: This is a mathematical projection, not a trading platform or a promise of returns. " +
                "The tax field applies the selected percentage to positive total profit at the end. " +
                "Actual tax treatment depends on the investment and applicable Indian tax rules.",
            style = MaterialTheme.typography.bodySmall
        )
    }
}

@Composable
private fun NumberInput(label: String, value: String, onValueChange: (String) -> Unit) {
    OutlinedTextField(
        value = value,
        onValueChange = { newValue -> if (newValue.matches(Regex("^\\d*\\.?\\d*$"))) onValueChange(newValue) },
        label = { Text(label) },
        singleLine = true,
        modifier = Modifier.fillMaxWidth()
    )
}

@Composable
private fun ResultLine(label: String, value: String, bold: Boolean = false) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
        Text(value, fontWeight = if (bold) FontWeight.Bold else FontWeight.Normal)
    }
}

private fun buildReport(
    principal: Double,
    dailyRate: Double,
    days: Int,
    type: String
): List<Snapshot> {
    if (days <= 0) return emptyList()
    val interval = when (type) {
        "Weekly" -> 7
        "Monthly" -> 30
        "Yearly" -> 365
        else -> 1
    }
    val rows = mutableListOf<Snapshot>()
    var previousBalance = principal
    var period = 1
    var day = interval
    while (day <= days) {
        val balance = principal * (1.0 + dailyRate).pow(day)
        rows.add(Snapshot(period, day, balance, balance - previousBalance, balance - principal))
        previousBalance = balance
        period++
        day += interval
    }
    if (rows.isEmpty() || rows.last().day != days) {
        val balance = principal * (1.0 + dailyRate).pow(days)
        rows.add(Snapshot(period, days, balance, balance - previousBalance, balance - principal))
    }
    return rows
}

private fun money(value: Double): String {
    val format = NumberFormat.getCurrencyInstance(Locale("en", "IN"))
    format.maximumFractionDigits = 2
    format.minimumFractionDigits = 2
    return format.format(value)
}

private fun percent(value: Double): String = String.format(Locale.US, "%.4f%%", value)

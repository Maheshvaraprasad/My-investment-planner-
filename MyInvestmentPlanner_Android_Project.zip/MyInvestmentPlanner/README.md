# My Investment Planner (Android)

A starter native Android app built with Kotlin and Jetpack Compose.

## Features
- INR investment amount
- Editable daily compound rate
- Duration in calendar days
- Editable tax estimate on positive profit at the end
- Daily, weekly (7-day), monthly (30-day), and yearly (365-day) reports
- Nominal APR and effective APY

## Calculation conventions
- Daily rate is entered as a percentage per calendar day.
- Balance after `n` days = principal × (1 + daily rate)^n.
- APR = daily rate × 365.
- APY = (1 + daily rate)^365 − 1.
- Tax is estimated at the end as tax rate × positive gross profit.
- Monthly report periods are fixed 30-day blocks; yearly report periods are fixed 365-day blocks.

This is a calculator only. It does not connect to a broker, place trades, or guarantee returns. Tax treatment depends on the actual investment and applicable law.

## Open and build in Android Studio
1. Install Android Studio on a computer (Windows, macOS, or Linux).
2. Extract this ZIP file.
3. In Android Studio choose **Open**, then select the extracted `MyInvestmentPlanner` folder (the folder containing `settings.gradle.kts`).
4. Allow Gradle sync to finish. If prompted, install Android SDK Platform 35 and a compatible JDK (Android Studio's bundled JDK is recommended).
5. To test, create an Android emulator in Device Manager or connect an Android phone with USB debugging enabled.
6. Press the green **Run** button and select your device.
7. To create an APK: **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
8. Android Studio will show a link to the generated APK. Copy it to your phone and open it to install. You may need to allow installation from that file manager.

## Notes
- This starter project does not include the Gradle wrapper. Open it with Android Studio, which can configure and run the Gradle build.
- `compileSdk` is 35. Android Studio may offer to install the SDK platform if it is missing.
